export const webhooks = {
    webhook1: "https://api.clay.com/v3/sources/webhook/pull-in-data-from-a-webhook-90daaca4-a9c9-40be-aa69-17245b91faa8",
    webhook2: "https://api.clay.com/v3/sources/webhook/pull-in-data-from-a-webhook-583c0378-a31d-47e9-ae07-e5af6a945e88",
    malo_tester: "https://api.clay.com/v3/sources/webhook/pull-in-data-from-a-webhook-b77d1251-bcae-41a4-9e36-b17082d5814e",
    tester: "https://hundreds-nightfall-52.webhook.cool"
};